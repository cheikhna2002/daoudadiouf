<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style.css">
</head>

<body class="presentation">
    <h1 class="moi">A propos de moi</h1>
    <p>
        Un jeune pasionne dans le domaine de l'informatique a travers ma portfolio je vais vous presenter mes projets
        tout d'abord je vais me presenter. <br>
        Mon nom c'est Cheikhna Diouf je suis en Licence2 en <strong>genie logiciel et adminidtration des
            reseaux</strong>.<br>
        Ma passion dans ce domaine est de pouvoir creer des sits web dynamique et utile dans mon
        environnement et developper des applications mobiles. <br>
        Je peux vous dire aujourd'hui que je maitrise le HTML le CSS et un peu le PHP Les langages que je suis entrain
        d'apprendre sont La programmation orientes objet le python et le PHP.
        J'ai realiser quelques projet que je vais vous presenter pour y acceder veuillez cliquer ici==><a
            href="./projet.php">Projets realises</a>
    </p>

</body>

</html>