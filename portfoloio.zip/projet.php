<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style.css">
</head>

<body class="mesprojets">
    <h1>MES PROJETS</h1>
    <p class="projet">Aujourd'hui je peut vous dire que j'ai realises quelques projets les uns a solo les autres en
        groupes. <br>
        Les voici👉<br></p>

    <p class="langagec">
        <strong>1.LANGAGE C</strong> <br>
        J'ai realisees un projet de <strong>Repertoire telephonique</strong> a tarvers laquelle on peut saisir <br> des
        contact enregistrer, supprimer et rechercher des contact enregistrer. <br>
        Differentes langage et logiciel ont ete utilisees pour realises ce projet parmi lesquelles ont peut citer: <br>
        Vscode, Apache qui est un package contenat un serveur web (Apache)
        une base de donnees(SQL) pour enregistrer les users etc.
    </p>
    <p class="systemeembarques">
        <strong>2.SYSTEME EMBARQUES</strong> <br>
        Sur ce projets nous l'avons executer en groupes c'etait un Poubelle programmer <br>
        avec le logiciel Arduino
        qui devait s'ouvrir et fermer a la moindre geste <br>
        grace au capteur de temperature avec des materiaux comme dht11
        esp32 des cables etc. <br>
    </p>

    <p class="projetporfolio">
        <strong>3.PORTFOLIO</strong><br>
        C'est le projet que je suis entrain de realiser auquel je dois me presenter montrer mes competences technique
        <br>
        presenter mes projets,mes experiences professionnels(j'en ai pas encore),<br>
        coder des formulaire pour me joindre etc.
    </p>
    <p>Pour ceux qui veulent me joindre par contact mail etc cliquez ici===> <a href="./formulaire.php">Mes
            contacts</a></p>
</body>

</html>